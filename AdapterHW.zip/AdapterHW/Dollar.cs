﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdapterHW
{
    public class Dollar
    {
        public double DollarPayment(double Money)
        {
            return Money *3.2;
        }
       
    }
}
